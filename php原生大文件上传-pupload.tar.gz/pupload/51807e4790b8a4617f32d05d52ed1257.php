<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<title>超大文件上传</title>
<script src="/plugins/jquery.min.js"></script>
<script type="text/javascript" src="js/plupload.full.min.js"></script>
<link rel="stylesheet" type="text/css" href="js/css.css">
</head>
<body>
<div class="puploaddom">
    <div id="filelist"></div>
    <div id="container" class="uploadbtn bka fs0">
        <a id="pickfiles" href="javascript:;" class='btn-shadow'>选择文件</a> 
        <a id="uploadfiles" href="javascript:;" class='btn-shadow'>立即上传</a>
    </div>
    <div id="result"></div>
    <pre id="console"></pre>
</div>
<script type="text/javascript">
var uploader = new plupload.Uploader({
	runtimes : 'html5,flash,silverlight,html4',
	browse_button : 'pickfiles',
	container: document.getElementById('container'),
	url : 'b80ce1257e1bedc6652f556831c8a339.php',
	chunk_size: '200kb',
	//flash_swf_url : 'js/Moxie.swf',
	//silverlight_xap_url : 'js/Moxie.xap',
	filters : {
		max_file_size : '9000mb',
		mime_types: [
			{title : "Image files", extensions : "jpg,gif,png,pdf"},
			{title : "Video files", extensions : "mp4"}
		]
	},

	init: {
		PostInit: function() {
			$("#filelist").html('')
			$("#uploadfiles").click(function(){
				uploader.start();
				return false;
			})
		},

		FilesAdded: function(up, files) {
			plupload.each(files, function(file) {
				$("#filelist").append('<div id="' + file.id + '"><span>' + file.name + ' (' + plupload.formatSize(file.size) + ') </span><b></b><input size="50" placeholder="请在此处复制上传地址"></div>');
			});
		},

		UploadProgress: function(up, file) {
			$("#" + file.id).find("b").html(file.percent + "%");
		},
		
		FileUploaded: function(up, file, res) {
			json = JSON.parse(res.response);
			$("#" + file.id).find("input").val(json['url']);
		},
		
		Error: function(up, err) {
			$("#console").html($("#console").html() + "<p>Error #" + err.code + ": " + err.message + "</p>");
		}
	}
});

uploader.init();
</script>
</body>
</html>
