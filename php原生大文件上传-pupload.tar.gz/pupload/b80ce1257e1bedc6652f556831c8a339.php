<?php
$root = dirname(__FILE__);
$document_root = $_SERVER['DOCUMENT_ROOT'];
header('Content-type:text/html; charset=UTF-8');
ini_set("display_errors", "On");
error_reporting(E_ALL);
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
function js($status, $msg = '', $url = '')
{
    $msg = array(
        "status" => $status,
        "msg" => $msg,
        "url" => $url
    );
    exit(json_encode($msg));
}

if (!isset($_REQUEST["name"])) {
    js('error', '请上传文件');
}

$extarr = explode(',', 'gif,png,jpg,zip,rar,pdf,doc,docx,xls,xlsx,mp4,ppt');
$filedir = "/f/image/" . date("Ymd") . "/";
$target = $document_root . $filedir;
$fname = $_REQUEST["name"];
$tmp_name = $_FILES["file"]["tmp_name"];
$ext = explode('.', $fname);
$ext = $ext[count($ext) - 1];
if (!in_array($ext, $extarr)) {
    js('error', '禁止的文件格式');
}
if (!file_exists($target)) {
    mkdir($target);
}
$filename = md5($fname) . ".{$ext}";
$fpath = $target . $filename;
$chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0;
$chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 0;
$out = @fopen("{$fpath}.part", $chunks ? "ab" : "wb");
if (!empty($_FILES)) {
    if (!$in = @fopen($tmp_name, "rb")) {
        js('error', 'Failed to open input stream');
    }
}
while ($buff = fread($in, 4096)) {
    fwrite($out, $buff);
}
@fclose($out);
@fclose($in);
if ($chunks > 0) {
    move_uploaded_file($tmp_name, "{$fpath}.tmp.chunk.{$chunk}");
    unlink("{$fpath}.tmp.chunk.{$chunk}");
}
if ($chunk == $chunks - 1) {
    rename("{$fpath}.part", $fpath);
    js('ok', '上传成功', "{$filedir}{$filename}");
} else if ($chunks == 0) {
    rename("{$fpath}.part", $fpath);
    move_uploaded_file($tmp_name, "{$fpath}.tmp");
    unlink("{$fpath}.tmp");
    js('ok', '上传成功', "{$filedir}{$filename}");
}
js('error', '请等待，文件尚未上传完毕', "");